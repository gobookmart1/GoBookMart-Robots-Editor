<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/*
Plugin Name: GoBookMart Robots Editor
Plugin URI:  https://gobookmart.com/wordpress-robots-editor
Description: Simple editor to create or edit a physical robots.txt file from WordPress admin. Developed by gobookmart.com.
Version:     1.0.1
Author:      GoBookMart
Author URI:  https://gobookmart.com
Text Domain: gobookmart-robots-editor
License:     GPLv2 or later
*/

// Removed redundant WP_Filesystem() calls from the top level.

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class GoBookMart_Robots_Editor {

	private $option_page = 'gobookmart-robots-editor';

	public function __construct() {
		add_action( 'admin_menu', array( $this, 'add_admin_page' ) );
		add_action( 'admin_init', array( $this, 'handle_post' ) );
		register_activation_hook( __FILE__, array( $this, 'maybe_create_default_robots' ) );
	}

	public function add_admin_page() {
		add_options_page(
			'Robots.txt Editor',
			'Robots Editor',
			'manage_options',
			$this->option_page,
			array( $this, 'render_admin_page' )
		);
	}

	/**
	 * Handles form submission securely.
	 * * Key changes:
	 * 1. Checks $_POST for the nonce instead of relying on an undefined global variable.
	 * 2. Uses check_admin_referer() for combined nonce and referrer verification.
	 * 3. Uses sanitize_textarea_field() on the POST data for secure input.
	 */
	public function handle_post() {
		// 1. Check if the form was submitted (by checking the nonce field)
		if ( ! isset( $_POST['gobookmart_robots_nonce'] ) ) {
			return;
		}

		// 2. Capability check (already correct)
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		// 3. Security check: Uses check_admin_referer for nonce verification.
		check_admin_referer( 'gobookmart_save_robots', 'gobookmart_robots_nonce' );

		// 4. Secure Input Handling: Get content from POST and sanitize it.
		// robots.txt requires line breaks and specific characters, so we sanitize for safety 
		// but avoid overly aggressive stripping that removes necessary format.
		$content = isset( $_POST['robots_content'] ) ? sanitize_textarea_field( wp_unslash( $_POST['robots_content'] ) ) : '';

		$result = $this->write_robots_file( $content );

		if ( $result ) {
			add_action( 'admin_notices', function() {
				echo '<div class="notice notice-success is-dismissible"><p>robots.txt saved successfully.</p></div>';
			} );
		} else {
			add_action( 'admin_notices', function() {
				echo '<div class="notice notice-error"><p>Could not write robots.txt — check file permissions or server configuration. (Failed to write using WP_Filesystem.)</p></div>';
			} );
		}
	}

	public function render_admin_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have sufficient permissions to access this page.', 'gobookmart-robots-editor' ) );
		}

		$home_path = function_exists( 'get_home_path' ) ? get_home_path() : ABSPATH;
		$robots_path = $home_path . 'robots.txt';
		$content = '';

		if ( file_exists( $robots_path ) ) {
			$content = file_get_contents( $robots_path );
		} else {
			ob_start();
			do_robots();
			$content = ob_get_clean();
		}

		?>
		<div class="wrap">
			<h1>Robots.txt Editor</h1>
			<p>Edit or create a physical <code>robots.txt</code> file for your site. Save to write the file to your site root (<?php echo esc_html( $robots_path ); ?>).</p>

			<form method="post" action="">
				<?php wp_nonce_field( 'gobookmart_save_robots', 'gobookmart_robots_nonce' ); ?>

				<textarea name="robots_content" rows="18" style="width:100%;max-width:100%;font-family: monospace;font-size:13px;"><?php echo esc_textarea( $content ); ?></textarea>

				<p class="submit">
					<input type="submit" class="button button-primary" value="<?php esc_attr_e( 'Save robots.txt', 'gobookmart-robots-editor' ); ?>">
				</p>
			</form>

			<p style="margin-top: 12px; font-size:13px;">
				<em>Developed by <a href="https://gobookmart.com" target="_blank" rel="noopener noreferrer">gobookmart.com</a></em>
			</p>
		</div>
		<?php
	}

	/**
	 * Writes the robots.txt file using the secure WP_Filesystem API exclusively.
	 * * Key changes:
	 * 1. Removed the insecure @file_put_contents and direct chmod fallback.
	 * 2. If WP_Filesystem fails, it returns false, triggering an error notice.
	 */
	private function write_robots_file( $content ) {
		$home_path = function_exists( 'get_home_path' ) ? get_home_path() : ABSPATH;
		$robots_path = $home_path . 'robots.txt';

		// Ensure WP_Filesystem is available
		if ( ! function_exists('WP_Filesystem') ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}
		
		// Attempt to initialize WP_Filesystem
		if ( ! WP_Filesystem() ) {
			// If WP_Filesystem cannot be initialized, request credentials
			$creds = request_filesystem_credentials( site_url( '/wp-admin/' ) );
			if ( false === $creds || ! WP_Filesystem( $creds ) ) {
				// Failed to get or use credentials
				return false; 
			}
		}

		global $wp_filesystem;
		
		// Ensure the directory is writable (optional, but keeps original intent)
		$dir = dirname( $robots_path );
		if ( ! $wp_filesystem->is_writable( $dir ) ) {
			// Attempt to change permissions, but WP_Filesystem is generally safer here.
			$wp_filesystem->chmod( $dir, FS_CHMOD_DIR ); 
		}
		
		// Use WP_Filesystem::put_contents() exclusively
		return (bool) $wp_filesystem->put_contents( $robots_path, $content, FS_CHMOD_FILE );

		// All fallback logic (@file_put_contents) has been removed.
	}

	public function maybe_create_default_robots() {
		$home_path = function_exists( 'get_home_path' ) ? get_home_path() : ABSPATH;
		$robots_path = $home_path . 'robots.txt';
		if ( ! file_exists( $robots_path ) ) {
			$default = "# robots.txt generated by GoBookMart Robots Editor\nUser-agent: *\nDisallow:\nSitemap: " . esc_url( home_url( '/sitemap.xml' ) ) . "\n";
			
			// Best practice: Use the secure method to write the default file as well
			$this->write_robots_file( $default ); 
		}
	}
}

new GoBookMart_Robots_Editor();