=== GoBookMart Robots Editor ===
Contributors: gobookmart, shashishekar45
Tags: robots.txt, SEO, crawler, search-engine, editor
Requires at least: 6.0
Tested up to: 6.8
Stable tag: 1.0.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A lightweight plugin to edit or create robots.txt directly from your WordPress dashboard. Developed by GoBookMart.

== Description ==

GoBookMart Robots Editor is a simple yet powerful WordPress plugin that lets you create, view, and modify your robots.txt file without needing FTP access or coding skills.

**Key Features:**
* Create or edit robots.txt from WordPress admin.
* Auto-generate a default SEO-friendly robots.txt.
* Save edits directly to your site root.
* Secure file handling using WordPress filesystem API.
* Lightweight, fast, and easy to use.

Perfect for SEO experts, developers, and site owners who want full control over how search engines crawl their websites.

Developed by [GoBookMart.com](https://gobookmart.com).

== Installation ==

1. Upload `gobookmart-robots-editor` to the `/wp-content/plugins/` directory or upload via WordPress admin.
2. Activate the plugin through the 'Plugins' menu.
3. Go to *Settings → Robots Editor* to start editing your robots.txt.

== Changelog ==

= 1.0.1 =
* Fixed Plugin URI and Author URI validation issue.
* Added `readme.txt` for WordPress.org compliance.

= 1.0.0 =
* Initial release with basic robots.txt editing capabilities.

== Frequently Asked Questions ==

= Where can I find the editor? =
Go to your WordPress dashboard → *Settings → Robots Editor*.

= Does it overwrite my existing robots.txt file? =
Yes, when you save changes, it updates or creates the physical robots.txt file in your WordPress root directory.

= Is it compatible with SEO plugins like Yoast or Rank Math? =
Yes. This plugin works independently and doesn’t conflict with major SEO tools.

== Upgrade Notice ==

= 1.0.1 =
Recommended update for plugin submission and WordPress.org compatibility.
